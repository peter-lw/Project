% STS, Fb. EIT, Hochschule Darmstadt
%�bung 5
%Stand: 13.09.2012
%a)
function [x]= genRechteck(A,f0,t)
x=A*sign(sin(2*pi*f0*t));
